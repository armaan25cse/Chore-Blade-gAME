#!/usr/bin/env ruby
# WEBrick local server for CHORE-BLADE
require 'webrick'

port = 8080
root = File.expand_path(File.dirname(__FILE__))

server = WEBrick::HTTPServer.new(
  Port: port,
  DocumentRoot: root,
  Logger: WEBrick::Log.new($stdout, WEBrick::Log::INFO),
  AccessLog: [[$stdout, WEBrick::AccessLog::COMBINED_LOG_FORMAT]]
)

trap('INT') { server.shutdown }
trap('TERM') { server.shutdown }

puts "\n" + "=" * 60
puts "⚔️  CHORE-BLADE // Data Realm Game Server Started!"
puts "🚀 Open in your browser: http://localhost:#{port}/"
puts "Press Ctrl+C to stop the server."
puts "=" * 60 + "\n\n"

server.start
