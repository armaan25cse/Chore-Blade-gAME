# ⚔️ CHORE-BLADE: The Data Realm

> **Transforming Mundane Digital Chores into High-Velocity Gameplay**
> *Where in-game gestures trigger real-world email triage, folder organization, and lint error fixes.*

---

## 🌟 Executive Overview & Design Philosophy

Digital procrastination rarely stems from physical exhaustion—it stems from **micro-decision fatigue**. Opening an inbox of 2,400 unread emails or a folder with 50 GB of orphan files requires dozens of repetitive micro-evaluations: *"Is this receipt safe to delete? Should I keep this newsletter? Which subfolder does this PDF belong to?"*

**CHORE-BLADE** resolves this psychological friction by coupling cognitive chore resolution with **high-dopamine arcade loops**. By translating complex digital maintenance actions into physical gestures (slashes, lasers, card swipes, spell casts), players enter a state of **flow** where chores are resolved automatically in the background.

---

## 🎮 The Four Core Design Concepts (Unified Prototype)

The system unifies the 4 design concepts requested into a cohesive experience:

| Concept | Game Mode | Mechanic | Real Chore Executed |
| :--- | :--- | :--- | :--- |
| **Concept 1: Arcade Slash & Shoot** | *Inbox Invaders: Cyber-Blade* | Fruit Ninja / Space Invaders style slicing and laser shooting | Gmail batch mark-as-read, archive, and priority tagging |
| **Concept 2: Interactive Dungeon Story** | *The Cyber-Librarian's Quest* | Text / Visual Novel RPG choices powered by LLM narrative structure | Vaulting receipts into Google Drive folders, muting spam wraiths |
| **Concept 3: Puzzle / Sorting Strategy** | *Workspace Janitor: Speed Deck* | Tinder / Reigns style rapid card swiping with streak multipliers | Drive orphan file cleanup, ESLint rule auto-fixes, expense reviews |
| **Concept 4: Tower Defense / Runner** | *Lint Slayer / Fever Mode* | Rhythm dodging & combo multipliers during overdrive | Auto-fixing TypeScript/Prettier code syntax and formatting |

---

## 🛡️ Safety Architecture: The Dual-State Guardrail Matrix

To prevent accidental data loss in fast-paced gaming, CHORE-BLADE employs a **Tiered Risk Matrix** and a **10-Second Time Freeze Capsule (Undo Buffer)**:

```mermaid
flowchart LR
    A["In-Game Gesture\n(Slash / Swipe / Blast)"] --> B["Game State Update\n(+100 XP, Combo x3, Audio SFX)"]
    A --> C["Chore Engine Queue"]
    C --> D{"Risk Evaluation"}
    D -- "Tier 0: Low Risk\n(Read / Star / Prettier)" --> E["Immediate Dispatch"]
    D -- "Tier 1 & 2: Destructive\n(Trash / Unsubscribe / Drive Delete)" --> F["10s Undo Buffer\n('Time Freeze Capsule')"]
    F -- "User hits 'U' or Revert" --> G["Action Cancelled & Restored"]
    F -- "10s Grace Timer Expires" --> H["Committed to API / CLI"]
```

### Risk Classification:
- **Tier 0 (Zero Risk)**: Mark Read, Star/Priority, Prettier Formatting. Dispatched instantly.
- **Tier 1 (Low Risk)**: Move to Archive folder, remove `INBOX` label. 10-second undo window.
- **Tier 2 (Medium Risk)**: Move to Trash, trigger one-click unsubscribe headers. 10-second countdown with visual timer pill.
- **Tier 3 (Quarantine / Boss Battle)**: Permanent hard delete. Banned from automatic execution; quarantined to review vault.

---

## ⚡ Technical Stack & Architecture

- **Canvas 2D Particle Engine (`game.js`)**: 60 FPS requestAnimationFrame loop, dynamic slicing trails, laser vector physics, particle bursts, screen shake, and floating combat text (`-120 KB FREED!`).
- **Zero-Dependency Audio Synthesizer (`audio.js`)**: 100% procedurally synthesized audio using the browser's Web Audio API (`AudioContext`, `BiquadFilterNode`, `OscillatorNode`). Includes blade whooshes, retro laser zaps, bass-heavy vaporize booms, and pentatonic combo chimes.
- **Chore Execution Pipeline (`chore-system.js`)**: Manages task models, state persistence, undo buffers, telemetry stats, and real API connectors.
- **Tailwind CSS UI (`index.html`)**: Clean cyber-industrial HUD with real-time storage counters, live API logs, and mode switchers.
- **Script Exporter**: One-click export to `chore-execute.sh` to run the completed tasks on your local terminal or CI/CD runner.

---

## 🚀 Quick Start Guide

### Option 1: Direct Browser Launch
Simply double click or open `index.html` in any modern web browser:
```bash
open index.html
```

### Option 2: Local Ruby Server
Run the included WEBrick server:
```bash
ruby server.rb
```
Then visit [http://localhost:8080](http://localhost:8080) in your browser.

---

## ⌨️ Controls & Keybindings

- **Arcade Slasher**:
  - `Drag / Mouse Swipe`: Cyber-Blade Slash (cuts through incoming flying chores)
  - `Click` or `Spacebar`: Fire Turret Laser at crosshairs
  - `U` Key: Instant Time-Warp Undo (cancels last queued chore)
- **Speed Deck Sorter**:
  - `A` or `Left Arrow`: Delete / Trash / Archive
  - `D` or `Right Arrow`: Keep & Star Priority
  - `W` or `Up Arrow`: Auto-Fix Code / Vault Document
- **Dungeon RPG**:
  - Click any choice to cast spells that resolve vault encounters!

---

## 🔌 Real API Connector Specification

To connect CHORE-BLADE to production APIs:

### 1. Gmail API Integration:
```http
PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/{messageId}/modify
Authorization: Bearer {oauth_token}
Content-Type: application/json

{
  "removeLabelIds": ["UNREAD", "INBOX"],
  "addLabelIds": ["ARCHIVE"]
}
```

### 2. Google Drive API Integration:
```http
PATCH https://www.googleapis.com/drive/v3/files/{fileId}
Authorization: Bearer {oauth_token}
Content-Type: application/json

{
  "trashed": true
}
```

### 3. Local ESLint / Prettier Bridge:
```bash
npx eslint --fix src/
npx prettier --write .
```
