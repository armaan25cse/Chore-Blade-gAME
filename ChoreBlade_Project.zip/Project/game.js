// CHORE-BLADE GAME ENGINE
// Manages Canvas 2D rendering, particle physics, slicing trails, laser projectiles, and multi-mode game loops

class GameApp {
  constructor() {
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    this.currentMode = 'arcade'; // 'arcade', 'deck', 'dungeon'

    // Canvas sizing
    this.width = 800;
    this.height = 540;

    // High DPI scaling
    this.scale = window.devicePixelRatio || 1;

    // Game state
    this.score = 0;
    this.combo = 0;
    this.feverGauge = 0;
    this.feverActive = false;
    this.feverTimer = 0;
    this.shakeAmount = 0;

    // Targets / Entities
    this.targets = [];
    this.particles = [];
    this.floatingTexts = [];
    this.lasers = [];
    this.slashTrail = [];

    // Mouse / Touch tracking
    this.mouse = { x: 0, y: 0, isDown: false, prevX: 0, prevY: 0, speed: 0 };

    // Deck Sorter state (Mode 2)
    this.deckCard = null;
    this.cardDrag = { x: 0, y: 0, isDragging: false, startX: 0, startY: 0 };

    // Dungeon RPG state (Mode 3)
    this.dungeonStory = null;
    this.dungeonHP = 100;
    this.dungeonFloor = 1;

    // Spawning parameters
    this.lastSpawnTime = 0;
    this.spawnInterval = 1400; // ms

    this.bindEvents();
    this.initCanvas();
    this.loadDungeonEncounter();
    this.loadNextDeckCard();
  }

  initCanvas() {
    if (!this.canvas) return;
    const rect = this.canvas.parentElement.getBoundingClientRect();
    this.width = Math.min(rect.width || 800, 920);
    this.height = 520;

    this.canvas.width = this.width * this.scale;
    this.canvas.height = this.height * this.scale;
    this.canvas.style.width = `${this.width}px`;
    this.canvas.style.height = `${this.height}px`;

    this.ctx = this.canvas.getContext('2d');
    this.ctx.scale(this.scale, this.scale);
  }

  bindEvents() {
    window.addEventListener('resize', () => this.initCanvas());

    // Mouse & Touch events on canvas
    if (this.canvas) {
      const getPos = (e) => {
        const rect = this.canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
          x: clientX - rect.left,
          y: clientY - rect.top
        };
      };

      const onPointerDown = (e) => {
        const pos = getPos(e);
        this.mouse.x = pos.x;
        this.mouse.y = pos.y;
        this.mouse.prevX = pos.x;
        this.mouse.prevY = pos.y;
        this.mouse.isDown = true;
        this.slashTrail = [{ x: pos.x, y: pos.y, age: 0 }];

        // Click / Laser shoot action
        if (this.currentMode === 'arcade') {
          this.shootLaser(pos.x, pos.y);
        }
      };

      const onPointerMove = (e) => {
        const pos = getPos(e);
        this.mouse.prevX = this.mouse.x;
        this.mouse.prevY = this.mouse.y;
        this.mouse.x = pos.x;
        this.mouse.y = pos.y;
        const dx = this.mouse.x - this.mouse.prevX;
        const dy = this.mouse.y - this.mouse.prevY;
        this.mouse.speed = Math.sqrt(dx * dx + dy * dy);

        if (this.mouse.isDown) {
          this.slashTrail.push({ x: pos.x, y: pos.y, age: 0 });
          // If swift motion, check slicing
          if (this.mouse.speed > 8) {
            this.checkSlashCollisions(this.mouse.prevX, this.mouse.prevY, this.mouse.x, this.mouse.y);
          }
        }
      };

      const onPointerUp = () => {
        this.mouse.isDown = false;
      };

      this.canvas.addEventListener('mousedown', onPointerDown);
      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('mouseup', onPointerUp);

      this.canvas.addEventListener('touchstart', (e) => { e.preventDefault(); onPointerDown(e); }, { passive: false });
      window.addEventListener('touchmove', (e) => { onPointerMove(e); }, { passive: true });
      window.addEventListener('touchend', onPointerUp);
    }

    // Keyboard controls
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        // Spacebar shoots laser or triggers Time Warp Undo
        if (this.currentMode === 'arcade') {
          e.preventDefault();
          this.shootLaser(this.mouse.x || this.width / 2, this.mouse.y || this.height - 40);
        }
      } else if (e.key === 'u' || e.key === 'U') {
        // 'U' for Instant Undo
        if (window.choreEngine && window.choreEngine.undoBuffer.length > 0) {
          const first = window.choreEngine.undoBuffer[0];
          window.choreEngine.undoAction(first.instanceId);
          window.soundEngine.playUndo();
          this.addFloatingText('TIME WARP UNDO!', this.width / 2, this.height / 2, '#38bdf8');
        }
      } else if (this.currentMode === 'deck') {
        if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
          this.handleDeckDecision('left');
        } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
          this.handleDeckDecision('right');
        } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          this.handleDeckDecision('up');
        }
      }
    });
  }

  setMode(mode) {
    this.currentMode = mode;
    this.targets = [];
    this.particles = [];
    this.floatingTexts = [];
    this.lasers = [];

    // Update tab UI buttons
    document.querySelectorAll('.mode-tab').forEach(btn => {
      if (btn.dataset.mode === mode) {
        btn.classList.add('bg-cyan-500/20', 'text-cyan-400', 'border-cyan-500/50');
        btn.classList.remove('text-zinc-400', 'border-zinc-800');
      } else {
        btn.classList.remove('bg-cyan-500/20', 'text-cyan-400', 'border-cyan-500/50');
        btn.classList.add('text-zinc-400', 'border-zinc-800');
      }
    });

    const arcadeCanvas = document.getElementById('arcadeContainer');
    const deckContainer = document.getElementById('deckContainer');
    const dungeonContainer = document.getElementById('dungeonContainer');

    if (arcadeCanvas) arcadeCanvas.style.display = (mode === 'arcade') ? 'block' : 'none';
    if (deckContainer) deckContainer.style.display = (mode === 'deck') ? 'block' : 'none';
    if (dungeonContainer) dungeonContainer.style.display = (mode === 'dungeon') ? 'block' : 'none';

    if (mode === 'deck') this.renderDeckCard();
    if (mode === 'dungeon') this.renderDungeon();
  }

  // Shoot laser cannon at coordinates
  shootLaser(targetX, targetY) {
    const originX = this.width / 2;
    const originY = this.height - 20;
    const angle = Math.atan2(targetY - originY, targetX - originX);
    const speed = 20;

    this.lasers.push({
      x: originX,
      y: originY,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 40
    });

    window.soundEngine.playLaser();

    // Check direct point collision with targets
    for (let i = this.targets.length - 1; i >= 0; i--) {
      const t = this.targets[i];
      const dist = Math.hypot(t.x - targetX, t.y - targetY);
      if (dist < t.radius + 15) {
        this.destroyTarget(t, 'shoot');
        break;
      }
    }
  }

  // Check if player's blade swipe cut any target
  checkSlashCollisions(x1, y1, x2, y2) {
    let hitCount = 0;
    for (let i = this.targets.length - 1; i >= 0; i--) {
      const t = this.targets[i];
      if (this.lineIntersectsCircle(x1, y1, x2, y2, t.x, t.y, t.radius)) {
        this.destroyTarget(t, 'slash');
        hitCount++;
      }
    }
    if (hitCount > 0) {
      window.soundEngine.playSlash();
    }
  }

  // Geometric line segment to circle collision test
  lineIntersectsCircle(x1, y1, x2, y2, cx, cy, r) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    if (lenSq === 0) return Math.hypot(cx - x1, cy - y1) <= r;

    const t = Math.max(0, Math.min(1, ((cx - x1) * dx + (cy - y1) * dy) / lenSq));
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    return Math.hypot(cx - projX, cy - projY) <= r;
  }

  // Handle target destruction & real chore execution
  destroyTarget(target, gestureType) {
    // Remove from active list
    const index = this.targets.indexOf(target);
    if (index !== -1) this.targets.splice(index, 1);

    // Increase combo & fever
    this.combo++;
    this.feverGauge = Math.min(100, this.feverGauge + 10);
    if (this.feverGauge >= 100 && !this.feverActive) {
      this.activateFever();
    }

    const multiplier = this.feverActive ? 2 : Math.min(Math.floor(this.combo / 4) + 1, 5);
    const points = 100 * multiplier;
    this.score += points;

    // Trigger Chore Engine execution!
    const result = window.choreEngine.executeAction(target.chore, gestureType);

    // Audio & Screen shake
    if (target.type === 'purple_bomb') {
      window.soundEngine.playExplosion();
      this.shakeAmount = 12;
    } else if (target.type === 'gold_powerup') {
      window.soundEngine.playStarPower();
    } else {
      if (this.combo % 3 === 0) {
        window.soundEngine.playCombo(multiplier);
      }
    }

    // Spawn rich particle burst
    this.spawnParticles(target.x, target.y, target.color, 24);

    // Spawn floating combat text with real saved data
    const sizeStr = target.chore.sizeBytes ? `${(target.chore.sizeBytes / 1024).toFixed(0)} KB` : '';
    this.addFloatingText(
      `+${points} | ${result.actionLabel} ${sizeStr ? '(' + sizeStr + ')' : ''}`,
      target.x,
      target.y,
      target.color
    );

    this.updateStatsUI();
  }

  activateFever() {
    this.feverActive = true;
    this.feverTimer = 180; // ~6 seconds at 30/60fps
    window.soundEngine.playFever();
    this.addFloatingText('⚡ FEVER OVERDRIVE! 2X SPEED & IMPACT ⚡', this.width / 2, 80, '#f59e0b', 22);
  }

  spawnParticles(x, y, color, count = 16) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 4 + 2,
        life: 1,
        decay: Math.random() * 0.03 + 0.02
      });
    }
  }

  addFloatingText(text, x, y, color = '#22d3ee', size = 14) {
    this.floatingTexts.push({
      text,
      x: Math.max(80, Math.min(x, this.width - 80)),
      y,
      vy: -1.4,
      color,
      size,
      alpha: 1,
      decay: 0.018
    });
  }

  // Spawn new flying chore target in Arcade mode
  spawnArcadeTarget() {
    const chore = window.choreEngine.spawnChore();
    
    let type = 'red_alien';
    let color = '#ef4444';
    let icon = '✉️';
    let label = 'Promo';

    if (chore.category === 'email_spam') {
      type = 'purple_bomb';
      color = '#a855f7';
      icon = '💣';
      label = 'Spam/Nuke';
    } else if (chore.category === 'email_priority') {
      type = 'gold_powerup';
      color = '#eab308';
      icon = '⭐';
      label = 'Priority';
    } else if (chore.category === 'drive_file') {
      type = 'blue_orb';
      color = '#38bdf8';
      icon = '📁';
      label = 'Cloud File';
    } else if (chore.category === 'code_lint') {
      type = 'green_glitch';
      color = '#22c55e';
      icon = '⚡';
      label = 'Lint Warning';
    }

    const radius = 32;
    const startX = Math.random() * (this.width - 140) + 70;
    const startY = -40;
    const targetVx = (Math.random() - 0.5) * 1.8;
    const targetVy = Math.random() * 1.5 + (this.feverActive ? 3.0 : 1.8);

    this.targets.push({
      x: startX,
      y: startY,
      vx: targetVx,
      vy: targetVy,
      radius,
      type,
      color,
      icon,
      label,
      chore,
      angle: 0,
      rotSpeed: (Math.random() - 0.5) * 0.04
    });
  }

  // --- MODE 2: SPEED DECK SORTER (Tinder / Reigns style) ---
  loadNextDeckCard() {
    this.deckCard = window.choreEngine.spawnChore();
    this.cardDrag = { x: 0, y: 0, isDragging: false, startX: 0, startY: 0 };
    this.renderDeckCard();
  }

  renderDeckCard() {
    const cardEl = document.getElementById('deckCardElement');
    if (!cardEl || !this.deckCard) return;

    const c = this.deckCard;
    let badgeClass = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
    let typeName = 'PROMOTIONAL EMAIL';

    if (c.category === 'email_spam') {
      badgeClass = 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      typeName = 'SPAM / NEWSLETTER';
    } else if (c.category === 'email_priority') {
      badgeClass = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      typeName = 'CRITICAL / PRIORITY';
    } else if (c.category === 'drive_file') {
      badgeClass = 'bg-sky-500/20 text-sky-300 border-sky-500/40';
      typeName = 'ORPHAN DRIVE STORAGE';
    } else if (c.category === 'code_lint') {
      badgeClass = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      typeName = 'ESLINT / CODE WARNING';
    }

    const sizeStr = c.sizeBytes ? `${(c.sizeBytes / (1024 * 1024)).toFixed(2)} MB` : '12 KB';

    cardEl.innerHTML = `
      <div class="flex items-center justify-between mb-3">
        <span class="text-xs font-mono uppercase px-2.5 py-0.5 rounded-full border ${badgeClass}">
          ${typeName}
        </span>
        <span class="text-xs font-mono text-zinc-400 bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700">
          Size: ${sizeStr}
        </span>
      </div>

      <h3 class="text-base font-bold text-zinc-100 mb-1 leading-snug">${c.title}</h3>
      <p class="text-xs text-zinc-400 font-mono mb-3">Source: ${c.sender}</p>

      <div class="bg-zinc-950/70 rounded-lg p-3 border border-zinc-800 text-xs text-zinc-300 mb-4 font-mono leading-relaxed">
        ${c.snippet}
      </div>

      <div class="border-t border-zinc-800/80 pt-3 flex items-center justify-between text-xs font-mono text-zinc-400">
        <div>API Risk: <span class="${c.risk === 'high' ? 'text-rose-400' : 'text-emerald-400'} uppercase font-bold">${c.risk}</span></div>
        <div class="text-cyan-400">Action: ${c.actionLabel}</div>
      </div>
    `;

    // Reset card transforms
    cardEl.style.transform = 'translate(0px, 0px) rotate(0deg)';
    cardEl.style.opacity = '1';
  }

  handleDeckDecision(direction) {
    if (!this.deckCard) return;
    const cardEl = document.getElementById('deckCardElement');
    let gesture = 'swipe_left';
    let label = 'Trashed / Deleted';

    if (direction === 'left') {
      gesture = 'swipe_left';
      label = 'REJECT & ARCHIVE';
      if (cardEl) cardEl.style.transform = 'translate(-300px, 20px) rotate(-20deg)';
    } else if (direction === 'right') {
      gesture = 'swipe_right';
      label = 'KEEP & STAR';
      if (cardEl) cardEl.style.transform = 'translate(300px, 20px) rotate(20deg)';
    } else if (direction === 'up') {
      gesture = 'swipe_up';
      label = 'AUTO-FIX & VAULT';
      if (cardEl) cardEl.style.transform = 'translate(0px, -240px) scale(0.8)';
    }

    if (cardEl) cardEl.style.opacity = '0';
    window.soundEngine.playSwipe();

    // Execute through chore engine
    window.choreEngine.executeAction(this.deckCard, gesture);
    this.score += 150;
    this.combo++;
    this.updateStatsUI();

    setTimeout(() => {
      this.loadNextDeckCard();
    }, 220);
  }

  // --- MODE 3: CYBER-LIBRARIAN DUNGEON RPG (Concept 2) ---
  loadDungeonEncounter() {
    const encounters = [
      {
        title: 'The Obsidian Crypt of Forgotten Invoices (2024)',
        description: 'You step into a dimly lit sub-chamber. A gargoyle carved from cold stone stands guard over 14 dusty PDF scrolls titled "Receipts_Q1-Q4_Scans.pdf". They are hoarding 4.2 GB of ancient cloud storage.',
        choices: [
          { text: 'Cast Incinerate (Permanently Trash Files)', action: 'trash', xp: 200, risk: 'Medium' },
          { text: 'Seal in Compressed Vault (Move to Drive Archive)', action: 'archive', xp: 250, risk: 'Zero' },
          { text: 'Summon Tax Accountant Golem (Auto-Tag & Categorize)', action: 'autotag', xp: 350, risk: 'Zero' }
        ]
      },
      {
        title: 'The Phantom Spambot of 1,000 Promotional Newsletters',
        description: 'A shadowy wraith swoops from the ceiling, chanting endless clickbait slogans: "Claim your 20% discount coupon!" It is draining your cognitive focus and filling your notifications inbox.',
        choices: [
          { text: 'Cast Exorcism (One-Click Unsubscribe + Vaporize)', action: 'unsub', xp: 300, risk: 'Zero' },
          { text: 'Shield with Spam Filter (Mark as Read & Mute Thread)', action: 'mute', xp: 180, risk: 'Zero' },
          { text: 'Tolerate the Phantom (Keep for weekend reading)', action: 'ignore', xp: -50, risk: 'Procrastination' }
        ]
      },
      {
        title: 'The Glitch Golem of Missing Semicolons & Unused Vars',
        description: 'An automaton forged of tangled TypeScript ast-nodes blocks the corridor. Its eyes flash with 48 ESLint errors: "variable is declared but never read" and "inconsistent indentation".',
        choices: [
          { text: 'Strike with Prettier Blade (Auto-Format Entire Repo)', action: 'prettier', xp: 280, risk: 'Safe' },
          { text: 'Invoke ESLint --fix (Auto-prune unused variables)', action: 'eslint', xp: 320, risk: 'Safe' },
          { text: 'Add // @ts-ignore (Coward\'s Retreat)', action: 'ignore_ts', xp: 10, risk: 'Technical Debt' }
        ]
      }
    ];

    this.dungeonStory = encounters[(this.dungeonFloor - 1) % encounters.length];
    this.renderDungeon();
  }

  renderDungeon() {
    const container = document.getElementById('dungeonContent');
    if (!container || !this.dungeonStory) return;

    const s = this.dungeonStory;
    container.innerHTML = `
      <div class="mb-4">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-mono px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded">
            VAULT CHAMBER #${this.dungeonFloor}
          </span>
          <span class="text-xs font-mono text-zinc-400">
            Digital Sanity: <span class="text-emerald-400 font-bold">${this.dungeonHP}%</span>
          </span>
        </div>
        <h3 class="text-lg font-bold text-zinc-100 mb-2">${s.title}</h3>
        <p class="text-sm text-zinc-300 leading-relaxed bg-zinc-950/60 p-4 rounded-xl border border-zinc-800/80 mb-5 font-serif italic">
          "${s.description}"
        </p>
      </div>

      <div class="space-y-3">
        ${s.choices.map((c, idx) => `
          <button onclick="window.gameApp.chooseDungeonOption(${idx})"
            class="w-full text-left p-3.5 rounded-xl border border-zinc-800 bg-zinc-900/60 hover:bg-cyan-500/10 hover:border-cyan-500/40 transition flex items-center justify-between group">
            <span class="text-sm font-medium text-zinc-200 group-hover:text-cyan-300">
              ⚔️ ${c.text}
            </span>
            <span class="text-xs font-mono text-cyan-400 opacity-80">
              +${c.xp} XP [${c.risk}]
            </span>
          </button>
        `).join('')}
      </div>
    `;
  }

  chooseDungeonOption(choiceIdx) {
    if (!this.dungeonStory) return;
    const choice = this.dungeonStory.choices[choiceIdx];
    
    // Spawn an action in Chore Engine
    const chore = window.choreEngine.spawnChore();
    window.choreEngine.executeAction(chore, 'dungeon_spell');
    
    this.score += choice.xp;
    this.dungeonFloor++;
    window.soundEngine.playStarPower();
    this.updateStatsUI();

    this.loadDungeonEncounter();
  }

  // Update UI stats headers
  updateStatsUI() {
    const scoreEl = document.getElementById('scoreValue');
    const comboEl = document.getElementById('comboValue');
    const feverBar = document.getElementById('feverFill');

    if (scoreEl) scoreEl.textContent = this.score.toLocaleString();
    if (comboEl) comboEl.textContent = `x${Math.max(1, Math.floor(this.combo / 4) + 1)}`;
    if (feverBar) feverBar.style.width = `${this.feverGauge}%`;
  }

  // Main 60fps game loop
  loop() {
    this.update();
    this.render();
    requestAnimationFrame(() => this.loop());
  }

  update() {
    // Fever countdown
    if (this.feverActive) {
      this.feverTimer--;
      if (this.feverTimer <= 0) {
        this.feverActive = false;
        this.feverGauge = 0;
      }
    } else {
      this.feverGauge = Math.max(0, this.feverGauge - 0.05);
    }

    // Screen shake decay
    if (this.shakeAmount > 0) {
      this.shakeAmount *= 0.88;
      if (this.shakeAmount < 0.1) this.shakeAmount = 0;
    }

    if (this.currentMode === 'arcade') {
      const now = Date.now();
      const currentInterval = this.feverActive ? this.spawnInterval * 0.5 : this.spawnInterval;
      if (now - this.lastSpawnTime > currentInterval) {
        this.spawnArcadeTarget();
        this.lastSpawnTime = now;
      }

      // Update targets
      for (let i = this.targets.length - 1; i >= 0; i--) {
        const t = this.targets[i];
        t.x += t.vx;
        t.y += t.vy;
        t.angle += t.rotSpeed;

        // Bounce horizontally
        if (t.x - t.radius < 0 || t.x + t.radius > this.width) {
          t.vx = -t.vx;
        }

        // Drop below screen (missed)
        if (t.y - t.radius > this.height) {
          this.targets.splice(i, 1);
          // Combo break
          if (this.combo > 0) {
            this.combo = 0;
            this.updateStatsUI();
          }
        }
      }

      // Update lasers
      for (let i = this.lasers.length - 1; i >= 0; i--) {
        const l = this.lasers[i];
        l.x += l.vx;
        l.y += l.vy;
        l.life--;
        if (l.life <= 0 || l.y < -20 || l.x < -20 || l.x > this.width + 20) {
          this.lasers.splice(i, 1);
        }
      }

      // Update slash trail decay
      for (let i = this.slashTrail.length - 1; i >= 0; i--) {
        this.slashTrail[i].age++;
        if (this.slashTrail[i].age > 10) {
          this.slashTrail.splice(i, 1);
        }
      }
    }

    // Update particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= p.decay;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Update floating combat texts
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.y += ft.vy;
      ft.alpha -= ft.decay;
      if (ft.alpha <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }
  }

  render() {
    if (!this.ctx || this.currentMode !== 'arcade') return;

    this.ctx.save();

    // Screen shake transform
    if (this.shakeAmount > 0) {
      const ox = (Math.random() - 0.5) * this.shakeAmount;
      const oy = (Math.random() - 0.5) * this.shakeAmount;
      this.ctx.translate(ox, oy);
    }

    // Clean background
    this.ctx.fillStyle = '#090d16';
    this.ctx.fillRect(0, 0, this.width, this.height);

    // Cyber grid lines
    this.ctx.strokeStyle = 'rgba(34, 211, 238, 0.05)';
    this.ctx.lineWidth = 1;
    for (let x = 0; x < this.width; x += 40) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, 0);
      this.ctx.lineTo(x, this.height);
      this.ctx.stroke();
    }
    for (let y = 0; y < this.height; y += 40) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(this.width, y);
      this.ctx.stroke();
    }

    // Fever overdrive glow effect
    if (this.feverActive) {
      this.ctx.strokeStyle = 'rgba(245, 158, 11, 0.25)';
      this.ctx.lineWidth = 4;
      this.ctx.strokeRect(4, 4, this.width - 8, this.height - 8);
    }

    // Draw Lasers
    for (const l of this.lasers) {
      this.ctx.save();
      this.ctx.strokeStyle = '#38bdf8';
      this.ctx.lineWidth = 3;
      this.ctx.shadowColor = '#38bdf8';
      this.ctx.shadowBlur = 10;
      this.ctx.beginPath();
      this.ctx.moveTo(l.x, l.y);
      this.ctx.lineTo(l.x - l.vx * 1.2, l.y - l.vy * 1.2);
      this.ctx.stroke();
      this.ctx.restore();
    }

    // Draw Targets (Flying chores)
    for (const t of this.targets) {
      this.ctx.save();
      this.ctx.translate(t.x, t.y);
      this.ctx.rotate(t.angle);

      // Outer glow circle
      this.ctx.beginPath();
      this.ctx.arc(0, 0, t.radius, 0, Math.PI * 2);
      this.ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      this.ctx.fill();

      this.ctx.lineWidth = 2.5;
      this.ctx.strokeStyle = t.color;
      this.ctx.shadowColor = t.color;
      this.ctx.shadowBlur = 14;
      this.ctx.stroke();

      // Icon & Label inside circle
      this.ctx.shadowBlur = 0;
      this.ctx.font = '22px sans-serif';
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      this.ctx.fillText(t.icon, 0, -4);

      this.ctx.font = '10px monospace';
      this.ctx.fillStyle = '#ffffff';
      this.ctx.fillText(t.label, 0, 16);

      this.ctx.restore();

      // Floating snippet teaser above target
      this.ctx.save();
      this.ctx.font = '11px sans-serif';
      this.ctx.fillStyle = 'rgba(203, 213, 225, 0.8)';
      this.ctx.textAlign = 'center';
      const shortTitle = t.chore.title.length > 28 ? t.chore.title.substring(0, 26) + '...' : t.chore.title;
      this.ctx.fillText(shortTitle, t.x, t.y - t.radius - 8);
      this.ctx.restore();
    }

    // Draw Particles
    for (const p of this.particles) {
      this.ctx.save();
      this.ctx.globalAlpha = p.life;
      this.ctx.fillStyle = p.color;
      this.ctx.shadowColor = p.color;
      this.ctx.shadowBlur = 8;
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }

    // Draw Blade Slash Trail (Fruit Ninja cyber-blade)
    if (this.slashTrail.length > 1) {
      this.ctx.save();
      for (let i = 1; i < this.slashTrail.length; i++) {
        const p1 = this.slashTrail[i - 1];
        const p2 = this.slashTrail[i];
        const alpha = Math.max(0, 1 - p2.age / 10);
        this.ctx.strokeStyle = `rgba(34, 211, 238, ${alpha})`;
        this.ctx.lineWidth = (10 - p2.age) * 0.8;
        this.ctx.shadowColor = '#06b6d4';
        this.ctx.shadowBlur = 12;
        this.ctx.lineCap = 'round';
        this.ctx.beginPath();
        this.ctx.moveTo(p1.x, p1.y);
        this.ctx.lineTo(p2.x, p2.y);
        this.ctx.stroke();
      }
      this.ctx.restore();
    }

    // Draw Floating Combat Texts
    for (const ft of this.floatingTexts) {
      this.ctx.save();
      this.ctx.globalAlpha = ft.alpha;
      this.ctx.font = `bold ${ft.size}px monospace`;
      this.ctx.fillStyle = ft.color;
      this.ctx.shadowColor = ft.color;
      this.ctx.shadowBlur = 10;
      this.ctx.textAlign = 'center';
      this.ctx.fillText(ft.text, ft.x, ft.y);
      this.ctx.restore();
    }

    // Cannon / Slasher Turret Base at bottom
    this.ctx.save();
    const cx = this.width / 2;
    const cy = this.height - 10;
    this.ctx.fillStyle = '#0284c7';
    this.ctx.shadowColor = '#38bdf8';
    this.ctx.shadowBlur = 15;
    this.ctx.beginPath();
    this.ctx.arc(cx, cy, 24, Math.PI, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();

    this.ctx.restore();
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.gameApp = new GameApp();
  window.gameApp.loop();
});
