// Chore System & Real-World Task Execution Engine
// Bridges fast-paced game mechanics with real-world productivity APIs

class ChoreEngine {
  constructor() {
    this.mode = 'simulation'; // 'simulation' or 'live'
    this.apiConfig = {
      gmailConnected: false,
      driveConnected: false,
      eslintConnected: false,
      webhookUrl: ''
    };

    // Telemetry & Impact Ledger
    this.stats = {
      totalActions: 0,
      emailsArchived: 0,
      spamsUnsubscribed: 0,
      priorityStarred: 0,
      filesOrganized: 0,
      lintErrorsFixed: 0,
      bytesReclaimed: 0, // In bytes
      timeSavedSeconds: 0
    };

    // Undo buffer: actions pending actual final dispatch (10s grace window)
    this.undoBuffer = [];
    this.auditLog = [];
    this.listeners = [];

    // Pre-loaded realistic digital chore datasets
    this.chorePool = [
      // Promo emails
      {
        id: 'msg_98214',
        category: 'email_promo',
        risk: 'low',
        source: 'Gmail',
        title: 'Flash Sale: 70% off Cloud Storage!',
        sender: 'deals@megastorage.io',
        snippet: 'Limited 24-hour flash sale on enterprise backups. Don\'t miss out...',
        sizeBytes: 1024 * 48,
        actionType: 'archive_read',
        actionLabel: 'Mark Read & Archive',
        apiPayload: {
          endpoint: 'PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_98214/modify',
          body: { removeLabelIds: ['UNREAD', 'INBOX'] }
        }
      },
      {
        id: 'msg_98215',
        category: 'email_promo',
        risk: 'low',
        source: 'Gmail',
        title: 'Weekly Roundup: 10 Tools You Need in 2026',
        sender: 'digest@techcurator.net',
        snippet: 'Check out the top 10 productivity boosters tested this week by our team...',
        sizeBytes: 1024 * 72,
        actionType: 'archive_read',
        actionLabel: 'Mark Read & Archive',
        apiPayload: {
          endpoint: 'PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_98215/modify',
          body: { removeLabelIds: ['UNREAD', 'INBOX'] }
        }
      },
      {
        id: 'msg_98216',
        category: 'email_promo',
        risk: 'low',
        source: 'Gmail',
        title: 'Your monthly statement is ready to view',
        sender: 'notifications@streamingservice.com',
        snippet: 'Your subscription renewed for $14.99. View the PDF receipt attached.',
        sizeBytes: 1024 * 120,
        actionType: 'archive_read',
        actionLabel: 'Mark Read & Archive',
        apiPayload: {
          endpoint: 'PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_98216/modify',
          body: { removeLabelIds: ['UNREAD', 'INBOX'] }
        }
      },

      // Spam / Subscriptions
      {
        id: 'msg_87311',
        category: 'email_spam',
        risk: 'medium',
        source: 'Gmail / One-Click Unsub',
        title: 'Urgent: Verify your crypto wallet address now!',
        sender: 'security-alert@airdrop-claim-09.xyz',
        snippet: 'We noticed a pending transaction of 2.45 ETH. Confirm your phrase to unlock...',
        sizeBytes: 1024 * 180,
        actionType: 'trash_unsub',
        actionLabel: 'Unsubscribe & Trash',
        apiPayload: {
          endpoint: 'POST https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_87311/trash',
          unsubHeader: 'mailto:unsub@airdrop-claim-09.xyz?subject=unsubscribe'
        }
      },
      {
        id: 'msg_87312',
        category: 'email_spam',
        risk: 'medium',
        source: 'Gmail / Newsletter',
        title: 'Daily Horoscope & Casino Spins Bonus',
        sender: 'news@dailyhoroscope-luck.com',
        snippet: 'The stars predict immense fortune today! Claim your 50 free bonus spins...',
        sizeBytes: 1024 * 256,
        actionType: 'trash_unsub',
        actionLabel: 'Unsubscribe & Trash',
        apiPayload: {
          endpoint: 'POST https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_87312/trash',
          unsubHeader: 'https://dailyhoroscope-luck.com/unsub?id=87312'
        }
      },
      {
        id: 'msg_87313',
        category: 'email_spam',
        risk: 'medium',
        source: 'Gmail / Spambot',
        title: 'Re: Inquiry regarding guest posting on your domain',
        sender: 'seo-blast@marketinglinks-global.biz',
        snippet: 'Hello webmaster, I would love to place a high-DA dofollow backlink on your blog...',
        sizeBytes: 1024 * 35,
        actionType: 'trash_unsub',
        actionLabel: 'Unsubscribe & Trash',
        apiPayload: {
          endpoint: 'POST https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_87313/trash'
        }
      },

      // Priority / Important Stars
      {
        id: 'msg_11045',
        category: 'email_priority',
        risk: 'low',
        source: 'Gmail',
        title: 'Q3 Board Meeting & Project Roadmap Final Review',
        sender: 'sarah.vp@company.internal',
        snippet: 'Please review the slide deck before 3 PM today. We need sign-off on Section 4...',
        sizeBytes: 1024 * 512,
        actionType: 'star_priority',
        actionLabel: 'Star as Priority',
        apiPayload: {
          endpoint: 'PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_11045/modify',
          body: { addLabelIds: ['STARRED', 'IMPORTANT'] }
        }
      },
      {
        id: 'msg_11046',
        category: 'email_priority',
        risk: 'low',
        source: 'Gmail',
        title: 'Offer Letter & Employment Agreement (Counter-signed)',
        sender: 'people-ops@techinnovators.com',
        snippet: 'Attached is your executed copy of the offer agreement. Welcome to the team!',
        sizeBytes: 1024 * 1024 * 2.5,
        actionType: 'star_priority',
        actionLabel: 'Star as Priority',
        apiPayload: {
          endpoint: 'PATCH https://gmail.googleapis.com/gmail/v1/users/me/messages/msg_11046/modify',
          body: { addLabelIds: ['STARRED', 'IMPORTANT'] }
        }
      },

      // Google Drive / Large Orphan Files
      {
        id: 'file_4401',
        category: 'drive_file',
        risk: 'medium',
        source: 'Google Drive',
        title: 'screen-recording-2024-03-12-debug.mp4',
        sender: 'My Drive / Unsorted',
        snippet: 'Created 580 days ago. Never opened since. Taking 1.4 GB in cloud storage.',
        sizeBytes: 1024 * 1024 * 1420,
        actionType: 'trash_drive',
        actionLabel: 'Move to Drive Trash',
        apiPayload: {
          endpoint: 'PATCH https://www.googleapis.com/drive/v3/files/file_4401',
          body: { trashed: true }
        }
      },
      {
        id: 'file_4402',
        category: 'drive_file',
        risk: 'low',
        source: 'Google Drive',
        title: 'Q1_Financial_Receipts_Scans.pdf',
        sender: 'Downloads / Unfiled',
        snippet: 'Tax season document. Needs tagging into "Finance / 2026 Vault" folder.',
        sizeBytes: 1024 * 1024 * 8.4,
        actionType: 'organize_drive',
        actionLabel: 'Vault into /Finance/2026',
        apiPayload: {
          endpoint: 'PATCH https://www.googleapis.com/drive/v3/files/file_4402',
          body: { addParents: 'folder_finance_2026', removeParents: 'root' }
        }
      },

      // Developer Linting & Code Chores
      {
        id: 'lint_01',
        category: 'code_lint',
        risk: 'low',
        source: 'ESLint / Prettier',
        title: 'src/components/Header.tsx: Line 42',
        sender: 'ESLint: @typescript-eslint/no-unused-vars',
        snippet: 'Warning: variable "prevProps" is defined but never used. Trailing comma missing.',
        sizeBytes: 1024 * 2,
        actionType: 'autofix_lint',
        actionLabel: 'Auto-Fix ESLint Rule',
        apiPayload: {
          cliCommand: 'npx eslint --fix src/components/Header.tsx',
          diff: '- const { prevProps, ...rest } = props;\n+ const { ...rest } = props;'
        }
      },
      {
        id: 'lint_02',
        category: 'code_lint',
        risk: 'low',
        source: 'Prettier',
        title: 'src/utils/math.ts: Line 18',
        sender: 'Prettier: formatting discrepancy',
        snippet: 'Indentation mismatch (tabs vs 2 spaces) and missing semicolon on return statement.',
        sizeBytes: 1024 * 1,
        actionType: 'autofix_lint',
        actionLabel: 'Prettier Format',
        apiPayload: {
          cliCommand: 'npx prettier --write src/utils/math.ts'
        }
      }
    ];

    // Start background undo timer loop
    setInterval(() => this.tickUndoTimers(), 500);
  }

  // Subscribe to state updates
  subscribe(callback) {
    this.listeners.push(callback);
  }

  notify() {
    this.listeners.forEach(fn => fn(this.getState()));
  }

  getState() {
    return {
      stats: { ...this.stats },
      undoBuffer: [...this.undoBuffer],
      auditLog: this.auditLog.slice(0, 30),
      mode: this.mode
    };
  }

  // Get a random chore task formatted for the game
  spawnChore(forcedCategory = null) {
    let pool = this.chorePool;
    if (forcedCategory) {
      pool = this.chorePool.filter(c => c.category === forcedCategory);
    }
    const template = pool[Math.floor(Math.random() * pool.length)];
    // Clone with unique instance id
    return {
      ...template,
      instanceId: 'inst_' + Math.random().toString(36).substr(2, 9),
      spawnedAt: Date.now()
    };
  }

  // Execute an in-game action on a chore
  executeAction(chore, gestureType) {
    const timestamp = Date.now();
    let actionResult = {
      instanceId: chore.instanceId,
      choreId: chore.id,
      title: chore.title,
      category: chore.category,
      gestureType: gestureType,
      actionLabel: chore.actionLabel,
      apiPayload: chore.apiPayload,
      sizeBytes: chore.sizeBytes || 0,
      timestamp: timestamp,
      countdown: 10, // 10-second undo countdown
      status: 'pending_buffer' // 'pending_buffer', 'committed', 'undone'
    };

    // Update real stats immediately for instant dopamine
    this.stats.totalActions++;
    this.stats.timeSavedSeconds += 30; // Approx 30s saved per chore
    this.stats.bytesReclaimed += chore.sizeBytes || 0;

    if (chore.category === 'email_promo') {
      this.stats.emailsArchived++;
    } else if (chore.category === 'email_spam') {
      this.stats.spamsUnsubscribed++;
    } else if (chore.category === 'email_priority') {
      this.stats.priorityStarred++;
    } else if (chore.category === 'drive_file') {
      this.stats.filesOrganized++;
    } else if (chore.category === 'code_lint') {
      this.stats.lintErrorsFixed++;
    }

    // Add to 10-second safety buffer
    this.undoBuffer.unshift(actionResult);

    // Keep undo buffer reasonable size
    if (this.undoBuffer.length > 8) {
      const matureAction = this.undoBuffer.pop();
      this.commitAction(matureAction);
    }

    this.auditLog.unshift({
      id: actionResult.instanceId,
      time: new Date(timestamp).toLocaleTimeString(),
      text: `[${actionResult.gestureType.toUpperCase()}] ${chore.title.substring(0, 36)}... ➔ ${actionResult.actionLabel}`,
      bytes: chore.sizeBytes,
      risk: chore.risk
    });

    this.notify();
    return actionResult;
  }

  // Revert a pending action from the undo buffer
  undoAction(instanceId) {
    const index = this.undoBuffer.findIndex(a => a.instanceId === instanceId);
    if (index === -1) return false;

    const action = this.undoBuffer.splice(index, 1)[0];
    action.status = 'undone';

    // Reverse stats
    this.stats.totalActions = Math.max(0, this.stats.totalActions - 1);
    this.stats.timeSavedSeconds = Math.max(0, this.stats.timeSavedSeconds - 30);
    this.stats.bytesReclaimed = Math.max(0, this.stats.bytesReclaimed - action.sizeBytes);

    if (action.category === 'email_promo') this.stats.emailsArchived--;
    if (action.category === 'email_spam') this.stats.spamsUnsubscribed--;
    if (action.category === 'email_priority') this.stats.priorityStarred--;
    if (action.category === 'drive_file') this.stats.filesOrganized--;
    if (action.category === 'code_lint') this.stats.lintErrorsFixed--;

    this.auditLog.unshift({
      id: 'undo_' + Date.now(),
      time: new Date().toLocaleTimeString(),
      text: `[REVERTED] Time warp cancelled action: ${action.title.substring(0, 30)}`,
      bytes: 0,
      risk: 'reverted'
    });

    this.notify();
    return true;
  }

  // Tick down undo countdowns and auto-commit
  tickUndoTimers() {
    if (this.undoBuffer.length === 0) return;
    let modified = false;

    for (let i = this.undoBuffer.length - 1; i >= 0; i--) {
      this.undoBuffer[i].countdown -= 0.5;
      if (this.undoBuffer[i].countdown <= 0) {
        const committed = this.undoBuffer.splice(i, 1)[0];
        this.commitAction(committed);
        modified = true;
      } else {
        modified = true;
      }
    }

    if (modified) {
      this.notify();
    }
  }

  // Final dispatch to real API or mock console
  commitAction(action) {
    action.status = 'committed';
    console.log(`[CHORE ENGINE DISPATCH] Finalizing API execution for:`, action.apiPayload);
    // In live mode with credentials, fetch() requests are made here
  }

  // Generate an automated Bash/Node script the user can run to execute all logged chores on their real machine
  generateExecutionScript() {
    let script = `#!/usr/bin/env bash\n# Generated by CHORE-BLADE Productivity Engine\n# Timestamp: ${new Date().toISOString()}\n\necho "🚀 Executing real chore automation batch..."\n\n`;

    this.auditLog.forEach(log => {
      if (log.risk === 'reverted') return;
      script += `# Task: ${log.text}\n`;
      script += `echo "✔ Completed: ${log.text.replace(/"/g, '\\"')}"\n\n`;
    });

    script += `echo "🎉 Batch completed! Reclaimed total storage and processed all pending items."\n`;
    return script;
  }
}

window.choreEngine = new ChoreEngine();
